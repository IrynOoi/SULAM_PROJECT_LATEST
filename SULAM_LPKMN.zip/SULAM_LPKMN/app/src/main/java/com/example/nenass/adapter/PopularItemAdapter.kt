//PopularItemAdapter
package com.example.nenass.adapter

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.nenass.databinding.PopularItemBinding
import com.example.nenass.model.PopularItem
import com.example.nenass.R

class PopularItemAdapter(
    private val itemList: List<PopularItem>
) : RecyclerView.Adapter<PopularItemAdapter.PopularItemViewHolder>() {

    inner class PopularItemViewHolder(val binding: PopularItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PopularItemViewHolder {
        val binding = PopularItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PopularItemViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PopularItemViewHolder, position: Int) {
        val item = itemList[position]

        // Set text
        holder.binding.popularItemName.text = item.name
        holder.binding.popularItemPrice.text = item.price
        holder.binding.popularItemPromoPrice.text = item.promo_price

        // Strike-through original price
        holder.binding.popularItemPrice.paintFlags =
            holder.binding.popularItemPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

        // Load image
        Glide.with(holder.itemView.context)
            .load(item.img_url)
            .placeholder(R.drawable.placeholder)
            .into(holder.binding.popularItemImg)
    }

    override fun getItemCount(): Int = itemList.size
}
