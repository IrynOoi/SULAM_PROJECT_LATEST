//ProfileFragment.kt
package com.example.nenass

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ProfileFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference

    // Views
    private lateinit var tvName: TextView
    private lateinit var tvPhone: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvAddress: TextView
    private lateinit var tvMemer: TextView
    private lateinit var ivProfile: ImageView
    private lateinit var ivBackground: ImageView
    private lateinit var btnEdit: Button
    private lateinit var btnSettings: ImageButton
    private lateinit var btnLogout: Button  // <-- Added

    // ActivityResultLauncher to handle returning from EditProfileActivity
    private lateinit var editProfileLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the launcher for EditProfileActivity
        editProfileLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                // Refresh profile data automatically after saving
                loadUserProfile()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(context, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        databaseReference = FirebaseDatabase.getInstance()
            .getReference("Users").child(currentUser.uid)

        // Initialize views
        tvName = view.findViewById(R.id.tvName)
        tvPhone = view.findViewById(R.id.tvPhone)
        tvEmail = view.findViewById(R.id.tvEmail)
        tvAddress = view.findViewById(R.id.tvAddress)
        tvMemer = view.findViewById(R.id.tvMemer)
        ivProfile = view.findViewById(R.id.ivProfileImage)
        ivBackground = view.findViewById(R.id.ivBackgroundImage)
        btnEdit = view.findViewById(R.id.btn_edit)
        btnSettings = view.findViewById(R.id.btnSettings)
        btnLogout = view.findViewById(R.id.btn_logout)  // <-- Added

        // Load profile data initially
        loadUserProfile()

        // Edit button launches EditProfileActivity
        btnEdit.setOnClickListener {
            val intent = Intent(requireContext(), EditProfileActivity::class.java)
            editProfileLauncher.launch(intent)
        }

        // Settings click (optional)
        btnSettings.setOnClickListener {
            Toast.makeText(context, "Settings clicked", Toast.LENGTH_SHORT).show()
        }

        // Logout button
        btnLogout.setOnClickListener {
            auth.signOut()  // Sign out from Firebase
            Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show()

            // Redirect to LoginActivity (replace with your login activity)
            val intent = Intent(requireContext(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

    private fun loadUserProfile() {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!isAdded) return

                tvName.text = snapshot.child("username").value?.toString() ?: ""
                tvPhone.text = snapshot.child("phone").value?.toString() ?: ""
                tvEmail.text = snapshot.child("email").value?.toString() ?: ""
                tvAddress.text = snapshot.child("address").value?.toString() ?: ""
                tvMemer.text = snapshot.child("memer").value?.toString() ?: "N/A"

                val profileUrl = snapshot.child("profileUrl").value?.toString() ?: ""
                if (profileUrl.isNotEmpty()) {
                    Glide.with(this@ProfileFragment)
                        .load(profileUrl)
                        .placeholder(R.drawable.user_profile)
                        .into(ivProfile)
                } else {
                    ivProfile.setImageResource(R.drawable.user_profile)
                }

                val backgroundUrl = snapshot.child("background").value?.toString() ?: ""
                if (backgroundUrl.isNotEmpty()) {
                    Glide.with(this@ProfileFragment)
                        .load(backgroundUrl)
                        .placeholder(R.drawable.top_bg)
                        .into(ivBackground)
                } else {
                    ivBackground.setImageResource(R.drawable.top_bg)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to load profile data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
