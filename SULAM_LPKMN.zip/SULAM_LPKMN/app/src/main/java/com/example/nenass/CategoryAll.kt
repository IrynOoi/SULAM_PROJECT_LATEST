//CategoryAll.kt
package com.example.nenass

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.nenass.adapter.ItemAdapter
import com.example.nenass.model.ItemModel
import com.google.firebase.firestore.FirebaseFirestore

class CategoryAll : AppCompatActivity() {

    private lateinit var rec: RecyclerView
    private lateinit var list: MutableList<ItemModel>
    private lateinit var adapter: ItemAdapter
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_all)

        // 🔙 Back Button
        val backBtn = findViewById<ImageView>(R.id.back_btn)
        backBtn.setOnClickListener {
            finish()   // closes this activity and returns to HomeFragment
        }

        // RecyclerView setup
        rec = findViewById(R.id.category_full_rec)
        rec.layoutManager = LinearLayoutManager(this)

        list = mutableListOf()
        adapter = ItemAdapter(this, list)
        rec.adapter = adapter

        loadItems()
    }

    private fun loadItems() {
        db.collection("items")
            .get()
            .addOnSuccessListener { result ->
                list.clear()
                for (doc in result) {
                    val item = ItemModel(
                        name = doc.getString("name") ?: "",
                        price = doc.getDouble("price") ?: 0.0,
                        img_url = doc.getString("img_url") ?: "",
                        category = doc.getString("category") ?: ""
                    )
                    list.add(item)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
            }
    }
}
