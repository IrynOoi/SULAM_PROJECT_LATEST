//OthersProfile.kt for activity_profile
package com.example.nenass

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class OthersProfile : AppCompatActivity() {

    private var btnFollowToggle: Button? = null
    private var profile: ImageView? = null
    private var bg: ImageView? = null
    private var username: TextView? = null
    private var memer: TextView? = null
    private var followingCount: TextView? = null
    private var followersCount: TextView? = null
    private var followers: TextView? = null
    private var following: TextView? = null
    private var backButton: ImageView? = null
    private var appbarTitle: TextView? = null

    private lateinit var auth: FirebaseAuth
    private lateinit var user: FirebaseUser
    private lateinit var reference: DatabaseReference

    private var id: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_other_profile)

        // Initialize views
        initViews()

        // Firebase setup
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        reference = FirebaseDatabase.getInstance().getReference("Users")

        // Back button click
        backButton?.setOnClickListener {
            onBackPressed() // goes back to previous activity/fragment
        }


        // Get UID from intent
        id = intent.getStringExtra("uid") ?: ""

        // Show follow button or settings
        if (id == user.uid) {
            btnFollowToggle?.apply {
                visibility = Button.VISIBLE
                text = "Settings"
            }
        } else {
            checkFollow()
        }

        // Load user data and counts
        getUserData()
        getFollowCount()

        // Followers/following click to navigate to ShowList
        followers?.setOnClickListener {
            val intent = Intent(this, ShowList::class.java)
            intent.putExtra("id", id)
            intent.putExtra("title", "Followers")
            startActivity(intent)
        }

        following?.setOnClickListener {
            val intent = Intent(this, ShowList::class.java)
            intent.putExtra("id", id)
            intent.putExtra("title", "Following")
            startActivity(intent)
        }

        // Follow/unfollow button click
        btnFollowToggle?.setOnClickListener {
            val currentText = btnFollowToggle?.text.toString()
            if (currentText == "Follow") {
                followUser()
            } else if (currentText == "Following") {
                unfollowUser()
            }
        }
    }

    private fun initViews() {
        btnFollowToggle = findViewById(R.id.btn_follow_toggle)
        profile = findViewById(R.id.profile_image)
        username = findViewById(R.id.username)
        memer = findViewById(R.id.memer)
        bg = findViewById(R.id.background)
        followingCount = findViewById(R.id.following_count)
        followersCount = findViewById(R.id.followers_count)
        followers = findViewById(R.id.followers)
        following = findViewById(R.id.following)
        backButton = findViewById(R.id.back_button)
        appbarTitle = findViewById(R.id.appbar_title)
    }

    private fun getUserData() {
        reference.child(id).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                username?.text = snapshot.child("username").value.toString()
                memer?.text = snapshot.child("memer").value.toString()
                Glide.with(this@OthersProfile)
                    .load(snapshot.child("profileUrl").value.toString())
                    .placeholder(R.drawable.user_profile)
                    .into(profile ?: return)
                Glide.with(this@OthersProfile)
                    .load(snapshot.child("background").value.toString())
                    .into(bg ?: return)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@OthersProfile, "Error loading profile", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    private fun getFollowCount() {
        FirebaseDatabase.getInstance().getReference("Follow")
            .child(id)
            .child("followers")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    followersCount?.text = snapshot.childrenCount.toString()
                }

                override fun onCancelled(error: DatabaseError) {}
            })

        FirebaseDatabase.getInstance().getReference("Follow")
            .child(id)
            .child("following")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    followingCount?.text = snapshot.childrenCount.toString()
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun checkFollow() {
        FirebaseDatabase.getInstance().getReference("Follow")
            .child(user.uid)
            .child("following")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.child(id).exists()) {
                        btnFollowToggle?.text = "Following"
                    } else {
                        btnFollowToggle?.text = "Follow"
                    }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun followUser() {
        FirebaseDatabase.getInstance().getReference("Follow")
            .child(user.uid)
            .child("following")
            .child(id).setValue(true)

        FirebaseDatabase.getInstance().getReference("Follow")
            .child(id)
            .child("followers")
            .child(user.uid).setValue(true)

        btnFollowToggle?.text = "Following"
//        addNotification()
    }

    private fun unfollowUser() {
        FirebaseDatabase.getInstance().getReference("Follow")
            .child(user.uid)
            .child("following")
            .child(id).removeValue()

        FirebaseDatabase.getInstance().getReference("Follow")
            .child(id)
            .child("followers")
            .child(user.uid).removeValue()

        btnFollowToggle?.text = "Follow"
    }

//    private fun addNotification() {
//        val notifRef = FirebaseDatabase.getInstance().getReference("Notifications").child(id)
//        val map = hashMapOf(
//            "userid" to user.uid,
//            "comment" to "started following you",
//            "postid" to "",
//            "ispost" to false
//        )
//        notifRef.push().setValue(map)
//    }
}
