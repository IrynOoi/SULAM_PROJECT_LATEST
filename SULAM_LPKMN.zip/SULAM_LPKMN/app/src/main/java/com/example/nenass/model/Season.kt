//Season
package com.example.nenass.model

data class Season(
    var start: String = "", // YYYY-MM-DD
    var end: String = ""
)