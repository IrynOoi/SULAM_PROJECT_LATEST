//ItemModel.kt
package com.example.nenass.model

data class ItemModel(
    val name: String = "",
    val price: Double = 0.0,
    val img_url: String = "",
    val category: String = ""   // or categoryId: String = ""
)
