//Popularitem.kt
package com.example.nenass.model


data class PopularItem(
    val id: String = "",
    val name: String = "",
    val price: String = "",
    val promo_price: String = "",
    val img_url: String = "",
    val ad_id: String = "" // Link to the related advertisement
)
