// User.kt-Firebase authentication
package com.example.nenass.model

data class User(val uid: String, val email: String)