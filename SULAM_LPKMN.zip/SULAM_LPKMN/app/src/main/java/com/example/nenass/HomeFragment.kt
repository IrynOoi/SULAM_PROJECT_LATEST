//HomeFragment.kt
package com.example.nenass

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.nenass.adapter.AdvertisementAdapter
import com.example.nenass.adapter.CategoryAdapter
import com.example.nenass.model.AdvertisementModel
import com.example.nenass.model.CategoryModel
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment() {

    private lateinit var popularRec: RecyclerView
    private lateinit var categoryRec: RecyclerView

    private lateinit var popularList: MutableList<AdvertisementModel>
    private lateinit var categoryList: MutableList<CategoryModel>

    private lateinit var popularAdapter: AdvertisementAdapter
    private lateinit var categoryAdapter: CategoryAdapter

    private val db = FirebaseFirestore.getInstance()
    private val TAG = "HomeFragment"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val root = inflater.inflate(R.layout.fragment_home, container, false)

        setupRecyclerViews(root)
        setupViewAllClicks(root)

        fetchPopularProducts()
        fetchCategories()

        return root
    }

    // -------------------------------------------------------------------------
    // SETUP RECYCLERS
    // -------------------------------------------------------------------------

    private fun setupRecyclerViews(root: View) {

        // POPULAR LIST (HORIZONTAL)
        popularRec = root.findViewById(R.id.pop_rec)
        popularRec.layoutManager = LinearLayoutManager(
            requireContext(), LinearLayoutManager.HORIZONTAL, false
        )
        popularList = mutableListOf()
        popularAdapter = AdvertisementAdapter(requireContext(), popularList)
        popularRec.adapter = popularAdapter

        // CATEGORY LIST (HORIZONTAL)
        categoryRec = root.findViewById(R.id.category_rec)
        categoryRec.layoutManager = LinearLayoutManager(
            requireContext(), LinearLayoutManager.HORIZONTAL, false
        )
        categoryList = mutableListOf()
        categoryAdapter = CategoryAdapter(requireContext(), categoryList)
        categoryRec.adapter = categoryAdapter
    }

    // -------------------------------------------------------------------------
    // VIEW ALL BUTTON LOGIC
    // -------------------------------------------------------------------------

    private fun setupViewAllClicks(root: View) {

//        val viewAllPopular = root.findViewById<TextView>(R.id.viewall)
        val viewAllCategory = root.findViewById<TextView>(R.id.viewall2)

//        // VIEW ALL POPULAR PRODUCTS
//        viewAllPopular.setOnClickListener {
//            val intent = Intent(requireContext(), CategoryAll::class.java)
//            intent.putExtra("type", "popular")
//            startActivity(intent)
//        }

        // VIEW ALL CATEGORIES
        viewAllCategory.setOnClickListener {
            val intent = Intent(requireContext(), CategoryAll::class.java)
            intent.putExtra("type", "category")
            startActivity(intent)
        }
    }

    // -------------------------------------------------------------------------
    // FIRESTORE FETCHING
    // -------------------------------------------------------------------------

    private fun fetchPopularProducts() {
        db.collection("advertisement")
            .get()
            .addOnSuccessListener { result ->
                popularList.clear()
                for (doc in result) {
                    val item = AdvertisementModel(
                        id = doc.id, // Ensure ID is populated
                        name = doc.getString("name") ?: "",
                        description = doc.getString("description") ?: "",
                        rating = doc.getString("rating")?.toFloatOrNull() ?: 0f,
                        discount = doc.getString("discount") ?: "",
                        type = doc.getString("type") ?: "",
                        img_url = doc.getString("img_url") ?: ""
                    )
                    popularList.add(item)
                }
                popularAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Log.e(TAG, "Error fetching popular products", it)
            }
    }

    private fun fetchCategories() {
        db.collection("category")
            .get()
            .addOnSuccessListener { result ->
                categoryList.clear()
                for (doc in result) {
                    val model = CategoryModel(
                        img_url = doc.getString("img_url") ?: "",
                        name = doc.getString("name") ?: ""
                    )
                    categoryList.add(model)
                }
                categoryAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Log.e(TAG, "Error fetching categories", it)
            }
    }
}
