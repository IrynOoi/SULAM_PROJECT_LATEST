//ItemActivity.kt
package com.example.nenass

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.nenass.adapter.ItemAdapter
import com.example.nenass.model.ItemModel
import com.google.firebase.firestore.FirebaseFirestore

class ItemActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var itemRec: RecyclerView
    private lateinit var itemList: MutableList<ItemModel>
    private lateinit var itemAdapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item)

        val categoryName = intent.getStringExtra("categoryName") ?: ""

        itemRec = findViewById(R.id.item_rec)
        itemRec.layoutManager = LinearLayoutManager(this)

        itemList = mutableListOf()
        itemAdapter = ItemAdapter(this, itemList)
        itemRec.adapter = itemAdapter

        // BACK BUTTON CLICK
        val backBtn: ImageView = findViewById(R.id.back_btn)
        backBtn.setOnClickListener {
            finish()
        }

        fetchItems(categoryName)
    }


    private fun fetchItems(category: String) {
        db.collection("items")
            .whereEqualTo("category", category)
            .get()
            .addOnSuccessListener { result ->
                itemList.clear()
                for (document in result) {
                    val item = ItemModel(
                        name = document.getString("name") ?: "",
                        price = document.getDouble("price") ?: 0.0,
                        img_url = document.getString("img_url") ?: "",
                        category = document.getString("category") ?: ""
                    )

                    itemList.add(item)
                }
                itemAdapter.notifyDataSetChanged()
            }
    }
}
