//CategoryModel.kt
package com.example.nenass.model

// For images loaded from URLs
data class CategoryModel(
    val img_url: String = "",
    val name: String = "",
)

