//PopularItemsActivity.kt
package com.example.nenass

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.nenass.adapter.PopularItemAdapter
import com.example.nenass.databinding.ActivityPopularBinding
import com.example.nenass.model.PopularItem
import com.google.firebase.firestore.FirebaseFirestore

class PopularItemsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPopularBinding
    private val db = FirebaseFirestore.getInstance()
    private val TAG = "PopularItemsActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize view binding
        binding = ActivityPopularBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adId = intent.getStringExtra("ad_id") ?: ""
        if (adId.isEmpty()) {
            Log.e(TAG, "No ad_id passed to PopularItemsActivity")
            return
        }
        Log.d(TAG, "Received ad_id=$adId")

        setupRecyclerView()
        fetchPopularItems(adId)

        // Back button functionality
        binding.backBtn.setOnClickListener {
            // Close this activity and go back
            finish()
        }
    }


    private fun setupRecyclerView() {
        binding.itemRec.layoutManager = LinearLayoutManager(this)
    }

    private fun fetchPopularItems(adId: String) {
        db.collection("popular_items")
            .whereEqualTo("ad_id", adId)
            .get()
            .addOnSuccessListener { snapshot ->
                Log.d(TAG, "Fetched ${snapshot.size()} items for adId=$adId")

                val popularList = snapshot.toObjects(PopularItem::class.java)
                if (popularList.isEmpty()) {
                    Log.w(TAG, "No popular items found for adId=$adId")
                }

                binding.itemRec.adapter = PopularItemAdapter(popularList)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error fetching popular items", e)
            }
    }
}
