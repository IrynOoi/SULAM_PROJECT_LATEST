//ItemAdapter.kt
package com.example.nenass.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.nenass.R
import com.example.nenass.model.ItemModel

class ItemAdapter(
    private val context: Context,
    private val itemList: List<ItemModel>
) : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImg: ImageView = itemView.findViewById(R.id.item_img)
        val itemName: TextView = itemView.findViewById(R.id.item_name)
        val itemPrice: TextView = itemView.findViewById(R.id.item_price)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]

        holder.itemName.text = item.name
        holder.itemPrice.text = "RM ${item.price}"

        Glide.with(context)
            .load(item.img_url)
            .placeholder(R.drawable.placeholder)
            .into(holder.itemImg)
    }

    override fun getItemCount(): Int = itemList.size
}
