//EditProfileActivity.kt
package com.example.nenass

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

class EditProfileActivity : AppCompatActivity() {

    private lateinit var ivProfile: ImageView
    private lateinit var btnEditProfileImage: ImageButton
    private lateinit var ivBackground: ImageView
    private lateinit var btnEditBackground: ImageButton

    private lateinit var etUsername: TextInputEditText
    private lateinit var etMemer: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etAddress: TextInputEditText
    private lateinit var btnSave: MaterialButton

    private lateinit var auth: FirebaseAuth
    private var selectedProfileImageUri: Uri? = null
    private var selectedBackgroundUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val uri = result.data!!.data
            if (pickingProfileImage) {
                selectedProfileImageUri = uri
                ivProfile.setImageURI(uri)
            } else {
                selectedBackgroundUri = uri
                ivBackground.setImageURI(uri)
            }
        }
    }

    private var pickingProfileImage = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        auth = FirebaseAuth.getInstance()

        // Views
        ivProfile = findViewById(R.id.ivEditProfileImage)
        btnEditProfileImage = findViewById(R.id.btnEditProfileImageEdit)
        ivBackground = findViewById(R.id.ivEditBackgroundPhoto)
        btnEditBackground = findViewById(R.id.btnEditBackgroundPhoto)

        etUsername = findViewById(R.id.etEditUsername)
        etMemer = findViewById(R.id.etEditMemer)
        etPhone = findViewById(R.id.etEditPhone)
        etEmail = findViewById(R.id.etEditEmail)
        etAddress = findViewById(R.id.etEditAddress)
        btnSave = findViewById(R.id.btnSaveProfile)

        loadUserProfile()

        btnEditProfileImage.setOnClickListener {
            pickingProfileImage = true
            pickImageFromGallery()
        }

        btnEditBackground.setOnClickListener {
            pickingProfileImage = false
            pickImageFromGallery()
        }

        btnSave.setOnClickListener {
            saveUserProfile()
        }
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        pickImageLauncher.launch(intent)
    }

    private fun loadUserProfile() {
        val databaseReference = FirebaseDatabase.getInstance()
            .getReference("Users")
            .child(auth.currentUser!!.uid)

        databaseReference.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                etUsername.setText(snapshot.child("username").value?.toString() ?: "")
                etMemer.setText(snapshot.child("memer").value?.toString() ?: "")
                etPhone.setText(snapshot.child("phone").value?.toString() ?: "")
                etEmail.setText(snapshot.child("email").value?.toString() ?: "")
                etAddress.setText(snapshot.child("address").value?.toString() ?: "")

                val profileUrl = snapshot.child("profileUrl").value?.toString()
                if (!profileUrl.isNullOrEmpty()) {
                    Glide.with(this).load(profileUrl).into(ivProfile)
                }

                val backgroundUrl = snapshot.child("background").value?.toString()
                if (!backgroundUrl.isNullOrEmpty()) {
                    Glide.with(this).load(backgroundUrl).into(ivBackground)
                }
            }
        }
    }

    private fun saveUserProfile() {
        val databaseReference = FirebaseDatabase.getInstance()
            .getReference("Users")
            .child(auth.currentUser!!.uid)

        val updates = hashMapOf<String, Any>(
            "username" to etUsername.text.toString(),
            "memer" to etMemer.text.toString(),
            "phone" to etPhone.text.toString(),
            "email" to etEmail.text.toString(),
            "address" to etAddress.text.toString()
        )

        databaseReference.updateChildren(updates)
            .addOnSuccessListener {
                if (selectedProfileImageUri != null) uploadProfileImage(selectedProfileImageUri!!)
                if (selectedBackgroundUri != null) uploadBackgroundImage(selectedBackgroundUri!!)

                Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show()

                // Set result OK to notify ProfileFragment
                setResult(RESULT_OK)
                finish()  // Close EditProfileActivity
            }
            .addOnFailureListener {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
            }
    }

    private fun uploadProfileImage(uri: Uri) {
        val storageRef = FirebaseStorage.getInstance()
            .getReference("profile_images/${auth.currentUser!!.uid}.jpg")

        storageRef.putFile(uri)
            .addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { url ->
                    FirebaseDatabase.getInstance().getReference("Users")
                        .child(auth.currentUser!!.uid)
                        .child("profileUrl")
                        .setValue(url.toString())
                }
            }
    }

    private fun uploadBackgroundImage(uri: Uri) {
        val storageRef = FirebaseStorage.getInstance()
            .getReference("background_images/${auth.currentUser!!.uid}.jpg")

        storageRef.putFile(uri)
            .addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { url ->
                    FirebaseDatabase.getInstance().getReference("Users")
                        .child(auth.currentUser!!.uid)
                        .child("background")
                        .setValue(url.toString())
                }
            }
    }
}
