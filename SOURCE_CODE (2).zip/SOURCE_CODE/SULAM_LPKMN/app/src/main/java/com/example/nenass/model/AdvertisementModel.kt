//AdvertisementModal.kt
package com.example.nenass.model


data class AdvertisementModel(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val rating: Float = 0f,  // keep Float
    val discount: String = "",
    val type: String = "",
    val img_url: String = ""
)



