//Other User Model
package com.example.nenass.model

data class UserModel(
    var user_id: String? = null,
    var username: String? = null,
    var memer: String? = null,
    var profileUrl: String? = null,
    var background: String? = null
)

